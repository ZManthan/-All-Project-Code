<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <title>Welcome to iDiscuss - Coding Forums</title>
    <link rel="stylesheet"  type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
    <style>
    #container{
      min-height: 87vh;
    }
    </style>
  </head>
  <body>
  <?php include 'partials/_dbconnect.php';?>
  <?php include 'partials/_header.php';?>
<div class="container my-3">
<form action="/forum/partials/_handlecontact.php" method="post"><section class="contact">
        <div class="content">
            <h2>Contact Us</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint tempore nobis quasi nihil eligendi
                voluptatem. Ab voluptatum quo pariatur exercitationem unde, nisi ipsam!
            </p>
        </div>
        <div class="container1">
            <div class="contactInfo">
                <div class="box">
                    <div class="icon"><img src="https://cdn-icons-png.flaticon.com/128/9077/9077975.png"
                     width="30px"></div>
                    <div class="text">
                        <h3>Address</h3>
                        <p>XYZ</p>
                    </div>
                </div>
                <div class="box">
                    <div class="icon"><img src="https://cdn-icons-png.flaticon.com/128/483/483947.png" 
                    width="20px"></div>
                    <div class="text">
                        <h3>Phone</h3>
                        <p>507-475-9080</p>
                    </div>
                </div>
                <div class="box">
                    <div class="icon"><img src="https://cdn-icons-png.flaticon.com/128/646/646094.png" 
                    width="30px"></div>
                    <div class="text">
                        <h3>Email</h3>
                        <p>Xyz01@gmail.com</p>
                    </div>
                </div>
            </div>
            <div class="contactForm">
              <form>
                <h2>Send Massage</h2>
                <div class="inputBox">
                  <input type="text" id="FullName" name="FullName" required="required">
                  <span>Full Name</span>
                </div>
                <div class="inputBox">
                  <input type="text" id="Email" name="Email" required="required">
                  <span>Email</span>
                </div>
                <div class="inputBox">
                  <textarea  id="Massage" name="Massage" required="required"></textarea>
                  <span>Type Your Massage...</span>
                </div>
                <div class="inputBox">
                  <input type="submit" name="" value="Send">
                </div>
              </form>
            </div>
        </div>
    </section> 
</div>
  <?php include 'partials/_footer.php';?> 
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>

