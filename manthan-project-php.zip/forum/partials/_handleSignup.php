<?php 
$showError = "false"; 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '_dbconnect.php';
    $user_name = $_POST['username'];
    $user_email= $_POST['signupEmail'];
    $pass = $_POST['signupPassword'];
    $cpass = $_POST['signupcPassword'];

    // Chack  Whether this email Exists
    $existsql = "select * from `users` where user_name = '$user_name'";
    $result = mysqli_query($conn, $existsql);
    $numRows = mysqli_num_rows($result);
    if ($numRows>0){
        $showError = "Username Already in use ";
    }

    else{
        if($pass == $cpass){
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $sql = "INSERT INTO `users` (`user_name`, `user_email`, `user_pass`, `timestamp`)
                      VALUES ('$user_name', '$user_email', '$hash',current_timestamp())";
            $result = mysqli_query($conn, $sql);
            if($result){
                $showAlert = true;
                header("Location:/forum/index.php?signupsuccess=true");
                exit();
            }
        }
        else{
        $showError = "Passwords do not match";
        }
    }
    header("Location:/forum/index.php?signupsuccess=false&error=$showError");
}

?>