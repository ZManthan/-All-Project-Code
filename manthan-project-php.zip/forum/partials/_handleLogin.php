<?php
$showError = "false";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '_dbconnect.php';
    $username = $_POST['username'];
    $pass = $_POST['loginPass'];

    // $sql = "Select * from users where user_email='$email'";
    $sql = "SELECT * FROM `users` WHERE user_name='$username'";

    $result = mysqli_query($conn, $sql);
    $numRows = mysqli_num_rows($result);
    if($numRows == 1){
        $row = mysqli_fetch_assoc($result);
        $hash = password_hash($pass, PASSWORD_DEFAULT);

        if (password_verify($pass, $hash)) {
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['sno'] = $row['sno'];
            $_SESSION['username'] =$username;
            echo "logged in".$username;
        }
        header("Location: /forum/index.php");  
    }
    header("Location: /forum/index.php");  
}

?> 