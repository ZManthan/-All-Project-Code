<div class="container-fluid bg-dark text-light">
    <!-- for fix footer line in bottam
             fixed-bottom   -->
    <p class="text-center py-2 mb-0">Copyright iDiscuss Coding Forum 2023 || All rights reserved</p>
</div>  