<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '_dbconnect.php';
    $Fname = $_POST['FullName'];
    $Email= $_POST['Email'];
    $Massage = $_POST['Massage'];
if($Massage){
            $sql = "INSERT INTO `contactus` (`FullName`, `Email`, `Massage`)
                    VALUES ('$Fname', ' $Email', '$Massage')";
            $result = mysqli_query($conn, $sql);
            if($result){
                $showAlert = true;
                header("Location:/forum/contact.php?massage=true");
                exit();
            }

        }
    }

        ?>