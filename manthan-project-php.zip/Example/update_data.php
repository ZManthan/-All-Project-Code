<?php 
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "test1";
 
 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn -> connect_error){
    die("Connection failed: " . $conn->connect_error);
}


$sql = "UPDATE Example SET LastName='Valani' WHERE UserID=2";

         if($conn -> query($sql) === true){
            echo "Record Updated SucceeFully";
         }
        else{
            echo "Error " .$conn->error;
        }

?>