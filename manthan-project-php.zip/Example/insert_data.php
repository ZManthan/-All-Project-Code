<?php 
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "test1";
 
 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn -> connect_error){
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO Example1 (FirstName, LastName, Address, City)
         VALUE ('Manthan', 'Sonani', 'Mota varacha', 'surat')";
        

         if($conn -> query($sql) === true){
            echo "Record Insrted SucceeFully";
         }
        else{
            echo "Error " .$conn->error;
        }

?>