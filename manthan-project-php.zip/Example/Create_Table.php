<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn -> connect_error){
    die("Connection failed: " . $conn->connect_error);
}

  $sql="CREATE TABLE Example1 (
    UserID int AUTO_INCREMENT PRIMARY KEY,
    FirstName varchar(255) Not Null,
    LastName varchar(255)  Not Null,
    Address varchar(255) Not Null,
    City varchar(255) Not Null
)";

if($conn->query($sql) === true){
    echo "Table Created SuccessFully";
}
else{
    echo "Error " .$conn->error;
}

$conn->close();
?>
