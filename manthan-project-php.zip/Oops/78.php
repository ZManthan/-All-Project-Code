<?php
    class Employee{
        // Properties of our Class
        public $name;
        public $salary;

        // Methods of Our Class
        // Constructor - It allows you to initialize objects. It is the code which is executed whenever a new object is instantiated.
        // Constructor without arguments
        // function __construct(){
        //     echo "This is my constructor for employee";
        // }

        // Constructor with arguments
        function __construct($name1, $salary1){
            $this->name = $name1;
            $this->salary = $salary1;

        }

    }

    $Manthan = new Employee("Manthan", 73000);
    $Henish = new Employee("Henish", 10000);
    $jigar = new Employee("jigar", 56000); 

    echo "The salary of Manthan is $Manthan->salary <br>";
    echo "The salary of Henish is $Henish->salary <br>";
    echo "The salary of jigar is $jigar->salary <br>";
?>