<?php 
    class Employee{
        public $name;
        public $lang;
        public $salary;
        
        public function __construct($name, $salary){
            $this->name = $name;
            $this->salary = $salary;
            $this->describe();
        }

        protected function describe(){
            echo "Name of the Programmer: $this->name <br>";
            echo "Salary of the programmer:$this->salary <br>";
        }
    }

    class Programmer extends Employee{
        public $lang="php";
        public function __construct($name, $lang, $salary){
            $this->name = $name;
            $this->lang = $lang;
            $this->salary = $salary;
            $this->describe();
        }
    }

    $Manthan = new Employee("Manthan",300000);
    $Het = new Employee("Het",4500);

?>      