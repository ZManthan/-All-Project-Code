<?php 
    define('a', 23);
    for ($i=1; $i <= 10 ; $i++) { 
        echo $i*a;
        echo "<br>";
    }
?>