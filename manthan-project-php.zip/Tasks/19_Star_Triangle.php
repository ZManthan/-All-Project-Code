<h3>Patten 1</h3>
<?php  
for($i = 0; $i <= 5; $i++){  
    for($j = 1; $j <= $i; $j++){  
        echo "* ";  
    }  
    echo "<br>";  
}  
?>


<h3>Patten 2</h3>
<?php  
for($i = 0; $i <= 5; $i++){  
    for($j = 5-$i; $j >= 1; $j--){  
        echo "* ";  
    }  
    echo "<br>";  
}  
?>


<h3>Patten 3</h3>
<?php  
    for($i=1; $i<=5; $i++){   
        for($j=1; $j<=$i; $j++){   
            echo ' * ';   
        }  
        echo '<br>';   
    }  
    for($i=5; $i>=1; $i--){   
        for($j=1; $j<=$i; $j++){  
            echo ' * ';   
        }   
        echo '<br>';   
    }   
    ?>  