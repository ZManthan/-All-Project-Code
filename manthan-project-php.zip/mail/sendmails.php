<?php 
    $to_email = "manthanzalavadiya8@gmail.com";
    $subject = "Email Testing via PHP";
    $body = "Hi, This tset Email send by PHP Script";
    $header = "From: zalavadiyamanthan@gmail.com";

    if(mail($to_email, $subject, $body, $header)){
        echo "Email Successfully Send to $to_email...";
    }
    else{
        echo "Email Sending failed...";
    }
?>