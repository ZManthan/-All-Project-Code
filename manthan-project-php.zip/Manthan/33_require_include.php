<?php

// include '_DataBase_Connection.php';
require '_DataBase_Connection.php';

$sql="SELECT * FROM `trip`  ";
$result=mysqli_query($conn,$sql);

//find the number of records returned
$num=mysqli_num_rows($result);
echo $num;
echo " Recored found in DataBase<br>";

while($row=mysqli_fetch_assoc($result)){
    // echo var_dump($row);
    echo $row['serial num'] . ". Hello ".$row['name']." Welcome To ".$row['dest'];
    echo "<br>";
} 

?> 