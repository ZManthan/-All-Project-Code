<?php

//Connecting to Database
$servername ='localhost';
$username='root';
$password='';
$database='Manthan22';

//Create a conaction
$conn=mysqli_connect($servername,$username,$password,$database);
//die  if connection was not successful
if (!$conn){
    die("Sorry we failed to connect:".mysqli_connect_errno());
}
else{
    echo "Connection was Successful <br>";
}

// Variables to be inserted into the table 
$name ="Het";
$Rolls = "Jprogramer";

//SQL Quare to be executed
$sql="INSERT INTO `trip` (`name`, `dest`) VALUES ('het', 'Australia');";
$result=mysqli_query($conn,$sql);

// add the new Emploeey Detail in emploeey Database
if($result){
    echo "the Record has been Inserted Successfully! <br>";
}
else{
    echo "the Record has been Not Inserted Successfully because of this error --->".
    mysqli_error($conn); 
}

?>