<?php

//Connecting to Database
$servername ='localhost';
$username='root';
$password='';

//Create a conaction
$conn=mysqli_connect($servername,$username,$password);

// Create a Data Base
$sql="CREATE DATABASE manthna2";    
$result=mysqli_query($conn,$sql);
echo "the Result is".var_dump($result);
echo "<br>";

//die  if connection was not successful
if (!$conn){
    die("Soory we failed to connect:".mysqli_connect_errno());
}

else{
    echo "Connection was Successful <br>";
}

//check For the Database creation Success
if($result){
    echo "the Database was created Successfully! <br>";
}

else{
    echo "the Database was not created Successfully because of this error --->".mysqli_error($conn); 
}
?>