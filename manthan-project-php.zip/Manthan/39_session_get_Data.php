<?php
// Start Sesstion And Get The Data 
session_start();
if (isset($_SESSION['username'])) {
    echo "Welcome ".$_SESSION['username'];
    echo "<br> Your Favorite Color is " .$_SESSION['favcol'];
    echo "<br>"; 
}
else{
    echo "Please login to Continue";
}

?>