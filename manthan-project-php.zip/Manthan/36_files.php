<?php

$fptr = fopen("file.txt","r");
// echo fgets($fptr);
// echo fgets($fptr);
// echo fgets($fptr);
// echo fgets($fptr); 
// echo var_dump(fgets($fptr));

/*
//Reding a file line by Line
while ($a=fgets($fptr)){
    echo $a;
}
echo "End of the File has been reached";
*/

// echo fgetc($fptr);
//Reding a file character by character
/*while ($a=fgetc($fptr)){
    echo $a;
    // break;
}
echo "End of the File has been reached";
*/

//Write a program Which reads the content of a file until. has been encountered 

while($a=fgetc($fptr)){
    echo $a;
    if($a== "."){
        break;
    }
}
fclose($fptr);

?>