<?php

$a=33; // Global variabel
$b=44;

function printvalue(){

    $a=55;     //local variabel
    $b=66;

    // global $a,$b;

    // this for function and local variabel
    echo "the value of variabel a is $a and value of b is $b<br>";
}

// function call
printvalue();

// this for Global variable
echo "the value of variabel a is $a and value of b is $b<br>";


?>