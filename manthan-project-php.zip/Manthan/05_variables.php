<?php 
    // echo "This is tutorial 5";
    // Variables are containers For Storing Information
    // Start With a $
    $name = "Manthan";
    $income = 200000;

    echo "This Guy is $name And his income is Rs. $income"; 
?>