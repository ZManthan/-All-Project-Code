<?php

$i=0;
do{  
echo "$i <br>";
$i++;
}            
while($i<5);

?>