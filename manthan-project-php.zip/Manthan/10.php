<?php 
$a=100;
$b=20;

if($a>20){
    echo "a is Grater than 20";
}
else{
    echo  "a is not Grater than 20";
}
echo "<br>"

?>

<?php

$age=25;
$age=65;

if ($age>66){
    echo "You can drive a car ";
}
else{
    echo "you can not Drive a car";
}
echo "<br>"

?>



