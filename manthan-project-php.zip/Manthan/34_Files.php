<?php
// for the Number OF Char
// $a= readfile("file.txt");
// echo "$a <br>";

readfile("file.txt");
?>