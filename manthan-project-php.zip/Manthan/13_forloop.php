<?php

for ($i=0; $i <5 ; $i++) { 
    echo "<br>";
    echo  $i;

}

?>