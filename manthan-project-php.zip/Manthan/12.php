<?php

$i=0;

while($i<100){
    echo "the value of i is ";
    echo $i;
    echo"<br>";
    $i+=3;

}



?>