<?php

//What is a SESSION 
// use to manege infoermation across Difference Pages

// Verify the User login info
session_start();
$_SESSION['username'] = "Manthan";
$_SESSION['favcol'] = "Black";
echo "We Have Saved your session";

?>