<?php
    echo "Hello world";
?>