<?php
echo "Welcome to the world of cookies <br>";

// cookies | Sesions

// Syntax to Set a cookies
setcookie("category","Books",time() + 86400,"/");
echo "The cookie is set<br>"; 
?>