<?php

$arr =array("Banana","apple","watermelen","Orange","Mango");

foreach ($arr as $value) {
    echo "$value <br>";
}

?>