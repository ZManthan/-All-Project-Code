<?php

$d=date("dS F Y");
echo "Today date is $d <br>";

$d=date("l");
echo "Today is $d <br>"; 

?>