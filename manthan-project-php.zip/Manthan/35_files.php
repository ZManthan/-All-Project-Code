<?php
// File Read karva Mate "r" No Upyog thi
$fptr =fopen("file.txt","r");
// echo $fptr;

// file nu name lakhva  ma bhul hoi & koi Error Hoi To aa Warnning Ave
// echo var_dump($fptr);
if (!$fptr){
    die("Unable to open this file.please enter a valid filename");
}
// File ni Ander Je Contant Hoi Te Batave
//fread Return The Contant
$content=fread($fptr,filesize("file.txt"));
echo $content; 

fclose($fptr)
?>