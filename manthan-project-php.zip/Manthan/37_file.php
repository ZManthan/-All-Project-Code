<?php

//Write files in php Using w mode
//  echo "Welcome to Write file in php";
// $fptr  =fopen("file2.txt","w");
// fwrite($fptr,"this Is a Best file on this planet. Plz Dont argue with me on this one.\n");
// fwrite($fptr,"This Id anouther content\n");
// fwrite($fptr,"This Id anouther content 02\n");
// fclose($fptr);

// Appending to a file in PHP
$fptr=fopen("file2.txt","a");
fwrite($fptr,"\nThis is being appended to the file \n");
fclose($fptr);


?>