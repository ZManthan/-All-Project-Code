<?php
echo "Welcome to the stage where we are ready to get connected to a database <br>";

/* 
Ways to connect to a MySQL Database
1. MySQLi extension
2. PDO
*/
// Connecting to the Database
$servername ='localhost';
$username='root';
$password='';

//Create a conaction
$conn=mysqli_connect($servername,$username,$password);

//die  if connection was not successful
if (!$conn){
    die("Soory we failed to connect:".mysqli_connect_errno());
}

else{
    echo "Connection was Successful";
}

?>