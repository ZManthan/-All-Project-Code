<?php

function Marks($marksArr){
    $sum=0;
    foreach ($marksArr as $value) {
        $sum+=$value;
    }
    return $sum;
}

$Manthan=[80,90,95,78,99,40];
$sumMarks=Marks($Manthan); 
echo  "Total marks  scored by manthan out of 600 is $sumMarks <br>" ;

$meet=[45,56,78,43,12,50];
$sumMarks=Marks($meet);
echo  "Total marks scored by meet out of 600 is $sumMarks <br>";

?>
<?php

function avgMarks($marksArr){
    $sum=0;
    $i=1;
    foreach ($marksArr as $value) {
        $sum+=$value;
        $i++;
    }
    return $sum/$i;
}

$Manthan=[80,90,95,78,99,40];
$sumMarks=avgMarks($Manthan); 
echo  "avg marks  scored by manthan is  $sumMarks <br>" ;

$meet=[45,56,78,43,12,50];
$sumMarks=avgMarks($meet);
echo  "avg marks scored by meet is $sumMarks <br> ";

?>
