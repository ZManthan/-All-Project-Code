<?php

$cat = $_COOKIE['category']; 
echo "Here is the list of all $cat";

?>