<?php

//Connecting to Database
$servername ='localhost';
$username='root';
$password='';
$database='Manthan22';

//Create a conaction
$conn=mysqli_connect($servername,$username,$password,$database);

//die  if connection was not successful
if (!$conn){
    die("Sorry we failed to connect:".mysqli_connect_errno());
}

else{
    echo "Connection was Successful <br>";
}

$sql="SELECT * FROM `employees` ";
$result=mysqli_query($conn,$sql);

//find the number of records returned
$num=mysqli_num_rows($result);
echo $num;
echo " Recored found in DataBase<br>";

//Display the rows retured by SQL query
if($num>0){
    // $row = mysqli_fetch_assoc($result);
    // echo var_dump($row);
    // echo "<br>";
    // $row = mysqli_fetch_assoc($result);
    // echo var_dump($row);
    // echo "<br>";
    // $row = mysqli_fetch_assoc($result);
    // echo var_dump($row);
    // echo "<br>";
    // $row = mysqli_fetch_assoc($result);
    // echo var_dump($row);
    // echo "<br>";

   // We can fetch in a better Way using the While loop
    while($row=mysqli_fetch_assoc($result)){
    // echo var_dump($row);
    echo $row['serial num'] . ". Hello ".$row['Name']." Your Are a ".$row['Rolls'] ." & Your Joining Date is ".$row['Date of joining'];
    echo "<br>";
} 

}
?>
