<?php

//Connecting to Database
$servername ='localhost';
$username='root';
$password='';
$database='Manthan22';

//Create a conaction
$conn=mysqli_connect($servername,$username,$password,$database);

//die  if connection was not successful
if (!$conn){
    die("Soory we failed to connect:".mysqli_connect_errno());
}

else{
    echo "Connection was Successful <br>";
}

// Create a table in the Database
$sql = "CREATE TABLE `Manthan22`.`employees` ( `serial num` INT NOT NULL AUTO_INCREMENT , `Name` VARCHAR(12) NOT NULL , 
`Rolls` VARCHAR(12) NOT NULL , `Date of joining` DATE NOT NULL , PRIMARY KEY (`serial num`)) ENGINE = InnoDB";

$result=mysqli_query($conn,$sql);

//check For the Table creation Success
if($result){
    echo "the table was created Successfully! <br>";
}

else{
    echo "the table was not created Successfully because of this error --->".mysqli_error($conn); 
}
?>


