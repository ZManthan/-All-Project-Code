<?php

$age=45; 

switch($age){

    case 15:
        echo "Your Age is 15 year";
        break;

    case 25:
        echo "Your Age is 25 year";
        break;

    case 35:
        echo "Your age is 35 year";
        break;

    case 45:
        echo "your age is 45 year";
        break;

    default:
    echo "you are Older men";
    break;
}

?>