<?php

$favcol=array('Manthan' => 'Black', 'heet'  => 'pink','het' => 'yellow' );

foreach ($favcol as  $key => $value) {
    echo "<br> Favorite color of  $key is $value";
}
?>