<?php
$insert=false;
$update=false;
$delete=false;
//  Connect to the Database
$servername ='localhost';
$username='root';
$password='';
$database='notes';

//Create a conaction
$conn=mysqli_connect($servername,$username,$password,$database);


//die  if connection was not successful
if (!$conn){
    die("Sorry we failed to connect:".mysqli_connect_errno());
}

if (isset($_GET['delete'])){
  $sno=$_GET['delete'];
  $delete = true;
  $sql = "DELETE FROM `notes` WHERE `sno` = $sno";
  $result = mysqli_query($conn, $sql);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
  if (isset($_POST['snoEdit'])) {
  
// //Update the Note
$sno = $_POST["snoEdit"];
$title = $_POST["titleEdit"];
$Description   = $_POST["DescriptionEdit"];

//SQL Quare to be executed
$sql="UPDATE `notes` SET `title` = '$title', `Description` = '$Description' WHERE `notes`.`sno` = '$sno'";
$result=mysqli_query($conn,$sql);

if($result){
  $update=true;
}
else{
  echo "We could not update the record successfully";
}
}
  else{
      $title = $_POST["title"];
      $Description   = $_POST["Description"];

    //SQL Quare to be executed
    $sql="INSERT INTO `notes` (`title`, `Description`) VALUES ('$title', '$Description')";
    $result=mysqli_query($conn,$sql);

    if($result){
        $insert =true;
    }
    else{
        echo "the Record has been Not Inserted Successfully because of this error --->".
        mysqli_error($conn); 
    }
  }
}  

?>

<!Doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">



  <title>iNotes - Notes taking made easy</title>
<!-- <style>
body  {
  background-image: url("paper.gif");
  background-color: #cccccc;
}
</style> -->
</head>

<body>
  <!-- Modal -->
  <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editModalLabel">Edit this note</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <form action="/crud/index.php" method="POST">
          <div class="modal-body">
            <input type="hidden" name="snoEdit" id="snoEdit">
            <div class="form-group">
              <label for="title">Note Title</label>
              <input type="title" class="form-control" id="titleEdit" name="titleEdit" aria-describedby="emailHelp">

            </div>
            <div class="form-group">
              <label for="desc">Note Description</label>
              <textarea class="form-control" placeholder="Leave a comment here" id="DescriptionEdit"
                name="DescriptionEdit"></textarea>
            </div>            
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMPEQ4QERAREBARExARERERDhAREBERFhYXGRcWFhYZHyoiGRsnHBYWJDojJystMD0wGCE2OzYvOiovMS0BCwsLDw4PGBERGC8lISUtLy06MDYvLy0tLS0yMTEvLjo0OTAvMS80LzA4LS8xNjAtLS0tLS8vMy8xLzQtLS8tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAQgEBQYHAgP/xABKEAACAQICAgoNCgQGAwAAAAAAAQIDBAURITEGBxIVQVFUYZHTCBMUFzVCU3GBkpOz0SIjMnSChKGipLRSYpTBJTM0coOxJLLC/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAEEBQMG/8QAKxEAAgIBAgYBAwUBAQAAAAAAAAECEQMhMQQSQVFhcYEykdETIlKh4fEF/9oADAMBAAIRAxEAPwDw0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG72MbGLnE6yoWtNzloc5v5NOlF+NOXAtfO8tCZ71sQ2m7KzUal0u7a60vtiyt4vTojS8bX4+erPJAFdsPwyvcNxoUKteS1xpUp1WvRFM6G22tsVqpOOH1kn5TcUn0TaZbC3oQpRUKcI04R0RjCKjFLmS0I/YAqotqXGOQP8AqbXrB3pMZ5C/6q06wtWACqvejxnkP6qz6wd6LGeQ/q7PrC1QAKq96LGeQ/q7PrB3osZ5D+rs+sLVAAqr3osZ5D+rs+sHeixnkP6uz6wtUACqveixnkP6uz6wd6PGeQ/qrPrC1QAKqd6TGeQv+qtOsI70uMcgf9TadYWsABUyvtY4tBZvD6ry/hlSqPojJmgxLBLm1/1FtXoLPLOrQqU03zOSWZdI+JxUk00mnoaazTQBR8FpdlW1Th9+pShSVpXeeVW3ioxz/npfRlp16nzngezbYPdYRUSrxUqU21SuKemlU4cv5ZZeK+J5ZrSAcsAAAAAAAAAAAAbvYjsdq4ndUrSivlT0ym03GlTX0py5l+LaXCaQsrtF7F1Z2Cupxyr3uVTN640Fn2uK8+mf2o56gDs9iuxyhhlvC2t4bmK0zlo7ZVnwzm+FvoWhLJI3ZAAJBAAJBAAJBAAJBAAJBAAJBAAJBAAJBAAJMDGMMpXlGrb16aq0qq3M4S1PiaetNPSmtKaTRnAAqXti7DJ4PddqbdShV3U7eq1pnFPTGWWjdxzSeXGnozyORLa7ZuxhYpYVqKjnXpp1rd8PbYJ5R+0s4+nPgKlAAAAAAAAAAGZhNk7ivb0IvKVarSop5Z5OpJRX/ZdG3oRpQhTglGEIxhCK1KMVkl0IqdtVW6q4vhsWs0qyqemnGU1+MUW2AABxmzq+qznb4dQe5nc6akk2nGlnllnxPKWfNF8Z1w4nlmoL79Elu36OeXIscXJ/9fQycU2dW1GTpwVS5qJ5NUYpwUuJzbSf2czG74FODSr2tzRT8bcxklztZp9CZqcSxujg/wD4llRhUuIxXbatRPKLazSeWlvLTuU0lmuHMwrTbEqt7i8oUa1CWiapwkpJceUm1LzaPOacOCjKHNHFKUe7kk35SppfJRlxTjLllkin25W0vDd/2el4diFK5pxq0akakJapRfDxNa0+Z6TLPOLhRwqvb3ltJysLtxVWObcUnpUlnwpNyXDokj0bMz8+FY6lF3GW3R6aNPyi5hyudqSqS36+mvD6EgArnYAAAAAAAAAAAAAAAAAAFRNsrDFaYriFGOiKrOpFcEY1UqkUuZKaXoLdlaOyBoKGLbpL/Mt6M3ztOcP+oIA80AAAAAAAAB2+0us8bw7z3H7eqWqKr7SfhvDvvP7asWoABxdXRjlPd+NR+az49xLPLokdocrs1wadVUbq2/1Ns1KKWuUU88suHJ56OFOSLXByjzyjJ1zRcb7N7fg4cQnyqSV0069b/leUeabJKUoXl2pZ5utUbz4c5Np+bJpmsy/E9CncWWLqLqTVneJKM4z0Kb1aN1kp8OWT3XGtR8w2LWVq+2XV5CUVpUItKU8uBJNyl5orM9DD/wBHHjioZYtTWnLTvTt0Zhz4LJkm542nF27tV89TGxCO4wK3jNZSlV+bT15OdSSy+zun5mekYfFqlRUvpKFNS/3blZnDW8ZYxc0pqnKnh9q/kRlHcqrJZaMtWnJLLgWfCz0LMxOOnooSVScpTa/jzNUvsra8mvwkdXJaqoxT78t2/WunoGsurW4lOThcdrhoyioU3lo54t/ibMGeXDT9xXfKvyUurHcV3yr8lLqzcAA0/cV3yr8lLqx3Fd8q/JS6s3AANP3Fd8q/JS6sdxXfKvyUurNwADT9xXfKvyUurHcV3yr8lLqzcAA0/cV3yr8lLqx3Fd8q/JS6s3AANTQtLlSg5XO6imt1Fwp/KXCtEE/xNsAACuXZGL/FLfnsqXvq5Y0rn2RvhS2+pUvfVwDyoAAAAAAAAHc7SfhvD/vP7asWnKsbSfhvD/vP7asWnAAAIBp8W2N2103KrRi5PXOOcZPz5a/SYNrsEsqTUlRcmuCU210LLM6YFiPFZ4x5Y5JJe2cZcPilLmlBN+kfFKlGEVGEVGMVlGMUoxS4klqPsArnYAAAAAAAAAAAAAAAAAAAAAFdOyN8J231Kl76uWLK59kZ4TtvqVL31ckHlYAAAAAAAAO42k/DeH/ef21YtQVX2k/DeH/ef21YtOASYeJ4hTtqcq1WW5hD0tvUoxXDJvQkZZxmyOLvMQtbRv5mmu21Vn9KTzen7KSX+9nOcuVab7fJY4XCsuSpOopNt+Fq/novZ80sQxHEM5W8Y2dDxJzipVJLPW3JNauCMdD4Wfq8PxWj8uN3TuMtdKcINS/LF9EkcxsyxypVrTtoS7VbUW6Sp059rVRx0Nyy8VPNKOrJZ+bQ2N1UtZqpQqTpyTzyjJuEuacNUk+cpyyxUqbb83X2Wx6DFwGSeNSjDHFNaRcbdeZb36/o9U2ObJFdSlRqQdC6hnuqUvHUXk5Qz08Waelc+s6I89x+67ZQssWpR3FaM4KaTyzkt0mm+FZxlHPhjI76lVU4xktUkpLzNZotYpt2n417p7GJxeCMOXJBUnacf4yj9S9dV4+5+gIPwq3lOD3M6tOMuKVSEX0NnUpGQDF3yo+Wpe1h8RvlR8tS9rD4gGUDF3yo+Wpe1h8RvlR8tS9rD4gGUDF3yo+Wpe1h8SN8qPl6PtafxAMsGLvlR8tS9rD4jfKj5al7WHxAMoGLvlR8tS9rD4jfKj5al7WHxAMoGNC+pSajGtSk3oSVSDbfMkzIAJK59kZ4TtvqVL39csWV07IzwnbfUqXv65IPKwAAAAAAAAdxtJ+G8P8AvP7asWnKsbSfhvD/ALz+2rFpgCTjsUqdzYtbVpf5deHat09Sk/k/99r9Y7E1eP4RC8pOnPQ9cJZZuMv7rjRzyRbX7d1qWuEywxzayfTJOL8J9fjc822X4RKhc1Xk3GrOVSDXCpNyy9DeXo50aijbylJJRcm3klk9L4Fz5ncq9urOLoXtr3ZQjkoVY/LlktWbkspvnbjLjz1kW+yCCb7iw2p23UpThBbnPR4jk8ubR5yg8UOb6q8U7/09Lj43iI40v0+dpfUpLkflu/2+U9V/R+OPUHb2FnY669acW463pbb/ABlGPSd5a0u1wpw/hjGHqpL+xzeAYFV7a7y8kp3MklGC+jSWnJJallm8lzttts6ouYo1bqtkvSMDjcykljTt3KUmtnKTV14SVAxK2G0pyc5QTk9b06TKJOxnmDvRR8muljeij5NdLM4E2DB3oo+TXSxvRR8mulmcBYMHeij5NdLG9FHya6WZwFgwd6KPk10sb0UfJrpZnAWDB3oo+TXSxvRR8mulmcBYMKGF0YtSVNZpprXoaM0EEAkrp2RnhO2+pUvf1yxRXXsjPCdt9Spe/rkg8rAAAAAAAAB3G0p4bw/7z+2rFpyrG0t4bw/7x+3qlpgASfIIB9DM/G4uIU1uqk4U4/xTnGK6WfjQxGlUe5p1qNSX8MKsJPoTF9Ca6mYQQAQSCAASSfJIJAIAIJJPkkEgk+SQCSAQAfRAIAPorp2RnhO2+pUvf1yxRXXsi/Cdt9Spe/uCSDysAAAAAAAAHb7S/hrD/Pcft6paYqvtMv8AxrD/AD1/cVS04BJqsexR28IqCUqtV5U4vVzya4Us1o42jaHP1o9sxGmpaqdNOK4M8m8+lroK/EykoJQ3bST7Xu/hWzvgjFyblsk37owK9jRoqNa/qupWnqj9KfmSXAubJI/OnLDrlqmlKjOWiDqRaTfBk82vxRrMXk53Fac9L3coRz8WCeSS6PxZi1IKSaazz4zzmbi8UMjisMZJOrlrJ11s2YcPOUVJ5Gn2WiXivB1djdVbStG2ryc6VRpUqjbbi3oUW3rT1adKeXAdMcdeydTDqMpt7uEtwpP6TybitPHko+lHV283KFOT1yjGT87SZu8Hku4W2qjJN78sr0femt/uZXEwpKdU7adbWvyj9gQa27xKdOcoq3nNLL5SlFJ6OAulU2YNPvxPk1T14/Ab8T5NU9ePwJog3ANPvxPk1T14/Ab71OTVPXj8BQNwDT78VOTVPXj8BvxPk1T14/AUDcA1DxifJqnrx+BG/E+TVPXj8BQNxmDT78T5NP14/Ab8VOTT9ePwFA3ANVRxWcpRi7epFSaWe6i8s+HI2hBJJXbsi/Cdt9Spe/uCxBXbsiX/AInb81lS99XJIPLAAAAAAAAAddtT1VDGMNb4arh6ZwlFf+xa0pngV/3Nc2txp+YrUauS1vcTUsvwLlRkpJNPNPSmtTT1MA+jntkClRq0byKclD5FSK1uOlfim/SkdAfFSCknGSTi1k09TRwz4v1IUnT0afZp2jrhyfpyurWqa7pnL4rhXb//ACLdqcKnyso5Z5vXo8/BrzzMO1wCtNpODiuFyTil/d+g21TY/OnJztbiVHdaXBvNN86aafpWfOJYVeVPk1Lx7l61BRg2vsRi/wATIycDCc3KWKdvVqLjyt9abaev3NKHFSjHljkjXdp8y9rq/RjYgo1ZULGi91ClLOpNalJZ5rRwrOTfO0tZ1MVkklqWSXmMPDMMp20dzBaeGT1v4IzTU4fC4c051brRbJLRL479fSRn5silUY7K9923u/8ACQQCycScwQACQQACQQACRmQACQQACcwQACSuHZA1d1isF/Ba0Yv0yqS/+ixxVLbUxFXOLYhUi84xq9pXF8zGNN5c2cG/SSQckAAAAAAAAAWf2nNkivsOpQlJOvaKNCqs/lbhL5qfmcFlnxwkVgOn2AbK54TdwrxTnSl83XpJ/wCZTb4P5lrT41lqbALZgwsIxOld0aVzQqRqUaq3UJL8U1wNPQ09KaZmEEkkAZgEgjMgAkkgAAkgAEkAZgAAZgE5kAAADMAAkg/K4rxpwnUqSjCnCLnOc5KMIRSzcpN6EkuEA1GzfZDHDLK4upNbuMdzRi/HrS0QWXDp0vmiyo1Sbk3KTbk2223m23rbZ3O2rs632uIwpZqzoOSpJ5xdST0SqyjwZ6knpS4m2cESQAAAAAAAAAAAAdZsH2c3GEVM6TVWhNp1bebapz4N1F+JPLxlzZp5FgtiW2BY4moqlVVKs9dvWahVz/l4J/Zb50iqIALs5HyVOwnZ5iVotzRvq6itUaklWgvNGopJeg6O326sTgluu5qnPOg036kkQCxwK8rbzxHyFi/+Gv1p9d/XEOT2HsrnrgCwgK99/XEOT2Hsrnrh39cQ5PYeyueuALCAr339cQ5PYeyueuHf1xDk9h7K564AsICvff1xDk9h7K564d/XEOT2HsrnrgCwgK99/XEOT2Hsrnrh39cQ5PYeyueuALCAr339cQ5PYeyueuIe3piPkLFf8Nx1oBYUFc623bictUbWHPGhNv8ANNmhxPbIxS5TjO+qxi+CluKGjizppNrzsUCx+ybZfZ4bFyua8YTyzjSi93Wl/tprT6Xkuc8A2wtsmvi2dGCdCzUs1RTznVafyZVZLXx7laE+NpM4apUcm5Sbcm2228229bb4WfmSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/9k=" width="35px"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact Us</a>
        </li>

      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </nav>
  <!-- <style type="text/css">
body
{
background-image:url("");
}
</style> -->

  <?php
  if($insert){
    echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
    <strong>Success!</strong> You Note has been inserted Successfullly!.
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>*</span>
    </button>
  </div>";
  }
?>

  <?php
  if($update){
    echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
    <strong>Success!</strong> You Note has been updated Successfullly!.
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>*</span>
    </button>
  </div>";
  }
?>

  <?php
  if($delete){
    echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>
    <strong>Success!</strong> You Note has been Deleted Successfullly!.
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>*</span>
    </button>
  </div>";
  }
  ?>

  <div class="container my-4">
    <h2>Add A Note to iNotes</h2>
    <form action="/crud/index.php" method="post">
      <div class="form-group">
        <label for="title" class="form-label">Note Title</label>
        <input type="title" class="form-control" id="title" name="title" aria-describedby="emailHelp">

      </div>
      <div class="form-group">
        <label for="desc">Note Description</label>
        <textarea class="form-control" placeholder="Leave a comment here" id="Description"
          name="Description"></textarea>
      </div>
      <button type="submit" class="btn btn-primary">Add Note</button>
    </form>
  </div>

  <div class="container my-4">

    <table class="table" id="myTable">
      <thead>
        <tr>
          <th scope="col">sno</th>
          <th scope="col">title</th>
          <th scope="col">Description</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $sql="SELECT * FROM `notes` ";
        $result=mysqli_query($conn,$sql);
        $sno = 0;
        while($row=mysqli_fetch_assoc($result)){
          $sno=$sno +1;
          echo "<tr>
          <th scope='row'>". $sno ."</th>
          <td>". $row['title'] ."</td>
          <td>". $row['Description'] ."</td>
          <td> <button class='edit btn btn-sm btn-primary' id=". $row['sno'] .">Edit</button>
               <button class='delete btn btn-sm btn-primary' id=d". $row['sno'] .">Delete</button></td>
        </tr>"; 
      } 

    ?>

      </tbody>
    </table>
  </div>
  <hr>

  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
    crossorigin="anonymous"></script>
  <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script>

    $(document).ready(function () {
      $('#myTable').DataTable();
    });
  </script>
  <script>
    edits = document.getElementsByClassName('edit');
    Array.from(edits).forEach((element) => {
      element.addEventListener("click", (e) => {
        console.log("edit");
        tr = e.target.parentNode.parentNode;
        title = tr.getElementsByTagName("td")[0].innerText;
        Description = tr.getElementsByTagName("td")[1].innerText;
        console.log(title, Description);
        titleEdit.value = title;
        DescriptionEdit.value = Description;
        snoEdit.value = e.target.id;
        console.log(e.target.id)
        $('#editModal').modal('toggle');
      })
    })

    deletes = document.getElementsByClassName('delete');
    Array.from(deletes).forEach((element) => {
      element.addEventListener("click", (e) => {
        console.log("edit");
        sno = e.target.id.substr(1,);

        if (confirm("Are You Sure You want to delete this note!")) {
          console.log("Yes");
          window.location = `/crud/index.php?delete=${sno}`;
          //Create the form and use post request to submit a form
        }
        else {
          console.log("NO");
        }
      })
    })
  </script>
</body>

</html>