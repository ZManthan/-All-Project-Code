-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2023 at 09:42 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `sno` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`sno`, `username`, `password`, `dt`) VALUES
(1, 'Manthan', '$2y$10$gmPVSc7zvOTk1fwtd4q99.cu6nJGBuBwcs1C0szkdnfpirHBNXj1S', '2023-05-15 20:46:43'),
(2, 'Meet', '$2y$10$FeydwYdlE/UqMAPcLynU/eHpDKUdcY//45GNS.8uqbgTH79grT2hS', '2023-05-15 20:46:55'),
(3, 'Us', '$2y$10$yPkE2lw73BYzVTr3sgpJBO4Dkr0mPbv/0kiXvBWvttUQboj9EJbCS', '2023-05-15 20:47:02'),
(4, '1', '$2y$10$orh8XzzQH6VajPQN6Nb1HuevxlKY.w1IHzbYiGJ3SuGapIiCI7sFm', '2023-05-15 20:47:07'),
(5, '12', '$2y$10$4Nut.IvSB9ezqtGyzgIqluTmJGiHO2ChAYN3SABhPsfIqUBpSuDlO', '2023-05-22 06:25:31'),
(6, '3', '$2y$10$Ze28jizEC1gtfojasxIdGeUGqfuTztQ2cQWGNrP7RQq8GyeBg.eYm', '2023-05-25 17:04:42'),
(7, 'Manthan1', '$2y$10$6b4qUB3JTSn9nQtgyOqy9OoMtanhFsbDLZ9Pu8OY2pql9Y804EAy.', '2023-05-25 17:09:54'),
(8, '', '$2y$10$IwowW.cfiktmRIHwcip4ouv0XaUy.1e4PEcfd9dUJyhcvbQPkdhzC', '2023-05-29 21:29:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
